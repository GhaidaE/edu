class InteractionsController < ApplicationController
  def leaf
  end
  
  
  def bee
  end
  
end