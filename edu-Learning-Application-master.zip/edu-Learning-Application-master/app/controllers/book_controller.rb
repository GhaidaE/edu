class BookController < ApplicationController
  def subject_select
  end
  
  
  def chapter_select
  end
  
  def interaction
  end
  
  def page
  end
  def page1
  end
  def page2
  end

  
end